tweet_placeName(698808155493507072,'Biscay').
tweet_placeName(698693922621677568,'Zapallar').
