user_location(2411466618,'Txurdinaga (Bilbao) ✈️ Dubai').
user_location(194231683,'España').
user_location(809843041,'Barcelona, Cataluña').
user_location(4277891398,'Sevilla, Andalucía').
user_location(977170688,'Manchester,England').
user_location(2382934933,'London, England').
user_location(2493310171,'Andalucía (España)').
user_location(2377584283,'México').
user_location(3031585030,'Home.').
user_location(1924556048,'Chihuahua, México').
user_location(3917981907,'Manchester, England').
user_location(3086364639,'Hamburg, Germany').
user_location(3917981907,'Manchester, England').
user_location(3917981907,'Manchester, England').
user_location(3250041992,'México').
user_location(2906414070,'Nicaragua').
user_location(121894769,'South Carolina').
user_location(371902119,'Manchester,England').
user_location(371902119,'Manchester,England').
user_location(3137404471,'Argentina y más allá').
user_location(471628526,'Buenos Aires, Argentina').
user_location(371902119,'Manchester,England').
user_location(3917981907,'Manchester, England').
user_location(726718026,'En el Corazón de NARRY & LILO').
user_location(192955835,'santo domingo').
user_location(203732257,'VIÑA DEL MAR').
user_location(3421123792,'Santiago ').
user_location(1024537303,'CURICO DE CHILE ').
user_location(143548575,'Santiago de chile').
user_location(57083275,'Chile, Campeón de América').
user_location(3376244577,'Brasil').
user_location(19355632,'Ciudadano del Mundo').
user_location(564961321,'Colombia').
user_location(2978384486,'Directioner De Corazón ').
user_location(2786174038,'Argentina').
user_location(2194910810,'México, Chihuahua').
user_location(704403435,'chile 5 r valparaiso la ligua ').
user_location(744119971,'mexico ').
user_location(463066719,'colombia parce').
user_location(2788348565,'Reino Unido').
user_location(272691968,'C O L O M B I A').
user_location(2900408190,'Somewhere World').
user_location(33259053,'Global').
user_location(2717209612,'Londres, Inglaterra').
user_location(33259053,'Global').
user_location(1062163142,'London ').
user_location(93967974,'Chile - Santiago').
user_location(560758470,'santiago de chile').
user_location(85324019,'Barcelona').
user_location(223011686,'ARICA-CHILE').
user_location(438754953,'5ta Región').
user_location(382601340,'Bs As Argentina').
user_location(118259541,'New Zealand').
user_location(2353835522,'Argentina').
user_location(3349779161,'En el ♡ Payno').
user_location(3039787462,'Asuncion, Paraguay').
user_location(602041039,'Paraguay').
user_location(246196807,'Málaga').
user_location(54481231,'EL Médano').
user_location(3419115568,'Buenos Aires, Argentina').
user_location(1643744318,'México').
user_location(2704717444,'México').
user_location(274719087,'ÜT: 41.7728736,2.7383873').
user_location(715309495,'Buenos Aires').
user_location(1494349520,'El Salvador').
user_location(471623367,'Mexico. Puebla, Puebla').
user_location(2727044420,'Yucatán, México').
user_location(2808189302,'Z016 || Someday Agus:)').
user_location(2415502973,'ARGENTINA').
