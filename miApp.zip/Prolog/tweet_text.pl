tweet_text(698808155493507072,"La vuelta al mundo... por 1402€. https://t.co/yk87End7ce").
tweet_text(698807088202567680,"Air New Zealand propone 1 billete único para dar la vuelta al mundo por menos de 1.500 euros https://t.co/qgI44nRbTM https://t.co/YO25Qsd9gT").
tweet_text(698794888582844416,"Un billete único para dar la vuelta al mundo por menos de 1.500 euros. https://t.co/FZ5E6qBwjs https://t.co/9Z9PeJVKN5").
tweet_text(698791976112672768,"6ª posición para @NJimenezPodium tras 2ª jornada del ISPS Handa New Zealand WO #golf #LET. Acumulado de -5 (70-69) https://t.co/iielFEK5fO").
tweet_text(698784832919314432,"#NewZealand - Guide To #Rotorua #Travel #Tourism #Social !#brand https://t.co/6TgMQuecnZ @Charlesfrize @DynamicFrize @Frizemedia #tourism").
tweet_text(698778691715751936,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698777104767393792,"Total de -5 (70-69-72) y 8ª posición final para Noemí Jiménez [@NJimenezPodium] en el ISPS Handa New Zealand Womens Open #golf #LET").
tweet_text(698776876672679936,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/Sbjy9eYqbz").
tweet_text(698776374463475712,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698762554806390784,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/Sbjy9eYqbz").
tweet_text(698762393615261696,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698762161691062272,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698761937937657856,"#NewZealand - Guide To #Rotorua #Travel #Tourism #Social !#brand https://t.co/6TgMQuecnZ @Charlesfrize @DynamicFrize @Frizemedia #tourism").
tweet_text(698761904332873728,"RT Charlesfrize: #NewZealand - Guide To #Rotorua #Travel #Tourism #vacation https://t.co/nqght7Xvg3 via Charlesfrize #thetraveller").
tweet_text(698761605656547328,"RT Charlesfrize: #NewZealand - Guide To #Rotorua #Travel #Tourism #vacation https://t.co/nqght7Xvg3 via Charlesfrize #thetraveller").
tweet_text(698761407320428544,"#NewZealand - Guide To #Rotorua #Travel #Tourism #vacation https://t.co/ukwLJq1Mqr via @Charlesfrize").
tweet_text(698760790355144704,"Simplemente ¡wow! Da la vuelta al mundo por... ¡menos de 1.500 euros! | Traveler: https://t.co/twcrTtJEBJ cc @kastwey").
tweet_text(698760597333241856,"#NewZealand - Guide To #Rotorua #Travel #Tourism #Social https://t.co/ukwLJq1Mqr via @Charlesfrize").
tweet_text(698760347914665984,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698759236566646784,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698758938985111552,"#NewZealand - Guide To #Rotorua #Travel #Tourism #Social https://t.co/ukwLJq1Mqr via @Charlesfrize").
tweet_text(698758667647217664,"#NewZealand - Guide To #Rotorua #Travel #Tourism #Social https://t.co/ukwLJq1Mqr via @Charlesfrize").
tweet_text(698756314172911616,"#NewZealand - Guide To #Rotorua #Travel #Tourism #vacation https://t.co/ukwLJq1Mqr via @Charlesfrize").
tweet_text(698755409893527552,"Air New Zealand: la vuelta al mundo por menos de 1.500 euros | Buena Vibra https://t.co/RPbZG70Cez by @Buenavibraes Muy interesante ...").
tweet_text(698752016210796544,"Air New Zealand propone un billete único para dar la vuelta al mundo por menos de 1.500 euros https://t.co/iaYpxusyrA").
tweet_text(698749896245977088,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698749770773458944,"#NewZealand - Guide To #Rotorua #Travel #Tourism #Social !#brand https://t.co/6TgMQuecnZ @Charlesfrize @DynamicFrize @Frizemedia #tourism").
tweet_text(698737806676508672,"#NewZealand - Guide To #Rotorua #Travel #Tourism #Social https://t.co/ukwLJq1Mqr via @Charlesfrize").
tweet_text(698736031839813632,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698734752807792640,"Terremoton de 5.9 a 17km de Christchurch, New Zealand, segun el centro de terremotos en China").
tweet_text(698729945707708416,"En New Zealand🇳🇿 no podía dejar de pasar a @adidasNZ y llevarme la camiseta del campeón #AllBlacks 🏉🏆💪 @adidasCL https://t.co/NTP1S27Zh0").
tweet_text(698729640924418048,"En New Zealand🇳🇿 no podía dejar de pasar a @adidasNZ y llevarme la camiseta del campeón #AllBlacks 🏉🏆💪 @adidasCL https://t.co/NTP1S27Zh0").
tweet_text(698728784858607616,"En New Zealand🇳🇿 no podía dejar de pasar a @adidasNZ y llevarme la camiseta del campeón #AllBlacks 🏉🏆💪 @adidasCL https://t.co/NTP1S27Zh0").
tweet_text(698728311497846784,"En New Zealand🇳🇿 no podía dejar de pasar a @adidasNZ y llevarme la camiseta del campeón #AllBlacks 🏉🏆💪 @adidasCL https://t.co/NTP1S27Zh0").
tweet_text(698728229029441536,"En New Zealand🇳🇿 no podía dejar de pasar a @adidasNZ y llevarme la camiseta del campeón #AllBlacks 🏉🏆💪 @adidasCL https://t.co/NTP1S27Zh0").
tweet_text(698728107998646272,"En New Zealand🇳🇿 no podía dejar de pasar a @adidasNZ y llevarme la camiseta del campeón #AllBlacks 🏉🏆💪 @adidasCL https://t.co/NTP1S27Zh0").
tweet_text(698728053858435072,"En New Zealand🇳🇿 no podía dejar de pasar a @adidasNZ y llevarme la camiseta del campeón #AllBlacks 🏉🏆💪 @adidasCL https://t.co/NTP1S27Zh0").
tweet_text(698726924387016704,"@pacificofilms  grabará con la New Zealand Symphony Orchestra (Lord Of The Rings y The Hobbit) Será la primer película del continente honor").
tweet_text(698717627682783232,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698717248974938112,"Dar la vuelta al mundo por menos de 1500€?! 😮 Donde firmo?? 😀😀😀@02B_com https://t.co/fDsIKjlY4J").
tweet_text(698715255770222592,"History ha sido certificado Oro por vender 7500 copias en New Zealand! #KCA #Humor1D #LarriesDeserveRespect").
tweet_text(698714796376588288,"History ha sido certificado Oro por vender 7500 copias en New Zealand! #KCA #Humor1D #LarriesDeserveRespect").
tweet_text(698706915413639168,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698705504487530496,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698703039243223040,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698701960904630272,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/Sbjy9eYqbz").
tweet_text(698699087390969856,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698698602814664704,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698696778246459392,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698696537203847168,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698695159538589696,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698693922621677568,"#sismo M5.8,  17km ENE of Christchurch, New Zealand, Hace 2 horas. Reportado a través de https://t.co/09010nlaYe https://t.co/g035PnCBEA").
tweet_text(698693769491775488,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698692582134714368,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698690538304892928,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698690517647884288,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698689174275280896,"#Sismo #Earthquake M 5.8 - 17km ENE of Christchurch, New Zealand https://t.co/apd1SoGCOF Si te sirvió la info dale ❤").
tweet_text(698684792712404992,"@jaco1853 para una respuesta tan segura   https://t.co/rKXSxEHwfk").
tweet_text(698681381090693120,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698680643362754560,"#NewZealand - Guide To #Rotorua #Travel #Tourism #Social https://t.co/ukwLJq1Mqr via @Charlesfrize").
tweet_text(698680447379738624,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698679493716680704,"#NewZealand - Guide To #Rotorua #Travel #Tourism #vacation https://t.co/ukwLJq1Mqr via @Charlesfrize").
tweet_text(698679242553425920,"#sismo M5.8,  17km ENE of Christchurch, New Zealand, Hace una hora. Reportado a través de https://t.co/Y3pQFOC18K").
tweet_text(698678165405724672,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698677756989677568,"Por qué New Zealand no es TT?").
tweet_text(698675747917934592,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698670219829583872,"AMPLIADO SISMO: magnitud 5.8: 17km ENE de Christchurch, New Zealand. 14 de Febrero, 00:13UTC, profunfidad. https://t.co/u9LFuMXIO1").
tweet_text(698666572077015040,"#sismo M5.8,  17km ENE of Christchurch, New Zealand, Hace 20 minutos. Reportado a través de https://t.co/KanuKAzkMP https://t.co/xIptLRdFBU").
tweet_text(698665111146405888,"Simplemente ¡wow! Da la vuelta al mundo por... ¡menos de 1.500 euros! | Traveler: https://t.co/twcrTtJEBJ cc @kastwey").
tweet_text(698664273107668992,"AHORA: SISMO PRELIMINAR: MAG 5.7 South Island, New Zealand, epicentro a 43.34°S 172.92°E y profundidad de 10km, https://t.co/mVFleNxwSd").
tweet_text(698663343381311488,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698662853465784320,"@GolazoUCV muchas gracias,  saludos desde New Zealand y aguante E4E!").
tweet_text(698662422089961472,"@pacificofilms  grabará con la New Zealand Symphony Orchestra (Lord Of The Rings y The Hobbit) Será la primer película del continente honor").
tweet_text(698661493869416448,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698660223213383680,"@GolazoUCV muchas gracias,  saludos desde New Zealand y aguante E4E!").
tweet_text(698653909779410944,"Mira como diseñar tu vuelta al mundo con Air New Zealand por menos de 1.500€ https://t.co/SxKcxawugq @FlyAirNZ https://t.co/Q6oeh41tpw").
tweet_text(698651505394651136,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698649844290727936,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698648400338821120,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698645674645176320,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698644207565729792,"Air New Zealand propone un billete único para dar la vuelta al mundo por menos de 1.500 euros https://t.co/Hj9SAVOioQ").
tweet_text(698643413533462528,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698642276130680832,"Air New Zealand propone un billete único para dar la vuelta al mundo por menos de 1.500 euros https://t.co/MVJ1cLffHq vía @02B_com").
tweet_text(698640041908813824,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698639207946846208,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698637518372143104,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698637183394172928,"Dar la vuelta al mundo por menos de 1500€?! 😮 Donde firmo?? 😀😀😀@02B_com https://t.co/fDsIKjlY4J").
tweet_text(698637161990643712,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698636459863969792,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698635172611289088,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698629822092677120,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698629743399321600,"Si compartes unas de mis grandes pasiones, viajar, este enlace te va a alegrar el día... y quizás la vida ;) https://t.co/9pZJjwS7RY").
tweet_text(698629013590384640,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698628545350733824,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698628184544137216,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698627848345620480,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/Sbjy9eYqbz").
tweet_text(698627600034328576,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698626624531488768,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
tweet_text(698626212072189952,"Da la vuelta al mundo por... ¡menos de 1.500 euros! https://t.co/tRdZVzUL7V").
tweet_text(698625845628444672,"El single History de 1D ha sido certificado Oro por vender 7,500 copias en New Zealand #Vote1DirectionUK #KCA https://t.co/vgGAVYGQck").
