tweet_placeCountry(698808155493507072,'España').
tweet_placeCountry(698693922621677568,'Chile').
