<?php
//access token
define('oauth_token','543547635-vr4hz9DemeOSFfQVSGR1oDW7rtCv0U7NZZZ2JeSq');
define('oauth_token_secret','fg5K0XhigQKpAO9ftig5oEirIkYIQDTIiUxWBpEUMyE');
//consumer token
define('CONSUMER_KEY', 'mQ8elYsDxmQ27S6oNSxeQ');
define('CONSUMER_SECRET', 'L3XhyzAYed1IZ5QsKZ4KnrpguDW1EZKMLqwum2P8');

define('OAUTH_CALLBACK', '');

?>
